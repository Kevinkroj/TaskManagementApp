export const setUsers = (users: any) => {
  return {
    type: "SET_USERS",
    payload: users,
  };
};
